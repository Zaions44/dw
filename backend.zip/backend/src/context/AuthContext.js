localStorage.setItem("token", response.data.token);

localStorage.removeItem("token");