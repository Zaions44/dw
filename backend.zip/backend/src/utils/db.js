const pg = require('pg');   //Importa o drive

const pool = new pg.Pool({
    host: 'localhost',
    user: 'postgres',       //Usuário criado durante a instalação
    password: 'ifc',       //Senha do usuário  
    database: 'login_jwt',      //Nome do banco de dados criado
    waitForConnections: true,
    connectionLimit: 10,
    port: 5432
});

module.exports = pool;