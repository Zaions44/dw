require('dotenv').config(); 
//const { swaggerDocs } = require('./src/config/swagger');
const express = require('express');
const helmet = require("helmet");
const cors = require('cors');
const rateLimit = require("express-rate-limit")
const cookieParser = require("cookie-parser")

const authRoutes = require('./src/routes/auth.routes');
const privateRoutes = require('./src/routes/private.routes');
const { swaggerDocs } = require('./src/utils/swagger.js'); 

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json())
app.use(cookieParser())

app.use(helmet())

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: "Muitas requisições deste IP, Tenta denovo depois meu"
})

app.use(limiter)

const corsOptions = {
    origin: ["http://localhost:5173"],
    methods: "GET,POST,PUT,DELETE",
    credentials: true
}


app.use(cors(corsOptions));

app.use('/api/auth', authRoutes);
app.use('/api/private', privateRoutes);
swaggerDocs(app);
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Documentação Swagger: http://${PORT}/api-docs`);
    
});